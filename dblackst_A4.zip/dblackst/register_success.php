<!-- HTML header, title, body tags, etc -->
<?php require("includes/header.php"); ?>

<!-- Main menu bar for all pages -->
<?php require("includes/main_menu_bar_https.php"); ?>

<div id="content-container">
    <div class="container">
        <h1>User successfully registered.</h1>
        <p>
            <a href="index.php">Back to home<a>
            <a href="login.php"> Log in<a>
        </p>
    </div>
<?php require("includes/footer.php"); ?>