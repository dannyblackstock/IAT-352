$(document).ready(function() {
    $('#user-dropdown').dropit();
});